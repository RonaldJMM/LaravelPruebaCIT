<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TBLEstado extends Model
{
    protected $table = 'TBL_Estado';

    protected $fillable = [

        'nombre',

    ];
}
