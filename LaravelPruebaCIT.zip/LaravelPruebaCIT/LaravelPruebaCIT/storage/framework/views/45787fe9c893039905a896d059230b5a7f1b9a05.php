<div class="alert alert-danger" role="alert">
   <h3>Esta pagina no es valida</h3>
</div><?php /**PATH D:\xampp\htdocs\LaravelPruebaCIT\LaravelPruebaCIT\resources\views/errors/404.blade.php ENDPATH**/ ?>