<?php $__env->startSection('editarPlatoUsuario'); ?>

<h1>Editar Plato de Usuario</h1>
<div class="alert alert-secondary" role="alert">
<table class="table table-sm table-striped table-bordered table-light">
    <thead>
    </thead>
    <tbody>

<form method="POST" action="<?php echo e(route('actualizarPlatoUsuario', $datosPlatoUsuario->id)); ?>" enctype="multipart/form-data">

    <?php echo e(method_field('PUT')); ?>

    <?php echo csrf_field(); ?>
    
    <tr>
        <td scope="col"><label for="nombre">Nombre:</label></td>
        <td scope="col"><input type="text" name="nombre" id="nombre" placeholder="example" value="<?php echo e($datosPlatoUsuario->nombre); ?>"></td>
    </tr>
    <tr>
        <td scope="col"><label for="descripcion">Descripcion:</label></td>
        <td scope="col"><input type="text" name="descripcion" id="descripcion" value="<?php echo e($datosPlatoUsuario->descripcion); ?>"></td>
    </tr>
    <tr>
        <td><label for="imagen">Imagen:</label></td>
        <td><input type="file" name="imagen" accept="image/png, .jpeg, .jpg, image/gif"></td>
    </tr>

    <tr><td colspan="1"><button type="submit" class="btn btn-info">Actualizar</button></td>
        
</form>

<form method="POST" action="<?php echo e(route('deshabilitarPlatoUsuario', $datosPlatoUsuario->id)); ?>">

    <?php echo e(method_field('PUT')); ?>

    <?php echo csrf_field(); ?>
    
    <?php if($datosPlatoUsuario->estado_id == 1): ?>
    <td colspan="2"><button type="submit" class="btn btn-danger">Deshabilitar</button></td>
    <?php else: ?>
    <td colspan="2"><button type="submit" class="btn btn-success">Habilitar</button></td>
    <?php endif; ?>
    </tr>
</form>

</tbody>
</table>  
</div>
<a class="btn btn-warning" href="<?php echo e(route('listarPlatosUsuario')); ?>" role="button">Regresar</a>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('content.usuario.contentUsuario', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\LaravelPruebaCIT\LaravelPruebaCIT\resources\views/content\usuario\plato\editarPlatoUsuario.blade.php ENDPATH**/ ?>