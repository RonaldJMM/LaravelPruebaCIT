<?php $__env->startSection('listarPlatosGenerales'); ?>

    <h1>Buscar Platos</h1>
    
    <div class="alert alert-secondary" role="alert">
    <div class="card bg-secondary text-white">
        <div class="card-body">
            <?php echo e($datosPlatosGenerales->total()); ?> registros | pagina <?php echo e($datosPlatosGenerales->currentPage()); ?> de <?php echo e($datosPlatosGenerales->lastPage()); ?>

        </div>
        </div>
        <br>
    <table class="table table-sm table-striped table-bordered table-light" >
        <thead class="thead-dark">
            <tr>
            <th scope="col">Imagen</th>
            <th scope="col">Nombre</th>
            <th scope="col">Información</th>                    
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $datosPlatosGenerales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php if($plato->estado_id == 1): ?>
                
            
                <tr>
                <td><img src="<?php echo e($plato->url_imagen); ?>" class="img-thumbnail border-dark rounded mx-auto d-block" height="50px" width="50px"></td>
                <td><?php echo e($plato->nombre); ?></td>
                <td>
                    <center>
                    <a class="btn btn-warning" href="<?php echo e(route('mostrarPlatoUsuario', $plato->id)); ?>" role="button"><img style="filter: invert(1)" src="<?php echo e(url('images/icons/info-circle-solid.svg')); ?>" height="30px" width="30px"></a>
                    
                    </center>
                </td>
                </tr>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
            <td colspan="3"><?php echo e($NDatosPlatos); ?></td>
            </tr>
            <?php endif; ?>
        </tbody>
        </table>
        <?php echo $datosPlatosGenerales->render(); ?>

    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('content.usuario.contentUsuario', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\LaravelPruebaCIT\LaravelPruebaCIT\resources\views/content/usuario/plato/listarPlatosGenerales.blade.php ENDPATH**/ ?>