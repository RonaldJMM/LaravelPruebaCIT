<?php $__env->startSection('mostrarPlatoUsuario'); ?>

    <h1>Datos de plato de Usuario</h1>
          
    <br>
    <table class="table table-sm table-striped table-bordered" >
        <thead class="thead-dark">
            <tr>
            <th scope="col">Imagen</th>
            <th scope="col">Nombre</th>
            <th scope="col">Descripcion</th>                    
            </tr>
        </thead>
        <tbody>
            <tr>
            <td><img src="<?php echo e($plato->url_imagen); ?>" class="img-thumbnail border-dark rounded mx-auto d-block" height="50px" width="50px"></td>
            <td><?php echo e($plato->nombre); ?></td>
            <td><?php echo e($plato->descripcion); ?></td>
            </tr>
            <tr><td colspan="3"><a class="btn btn-warning" href="<?php echo e(route('regresarInicio')); ?>" role="button">Regresar al Inicio</a></td></tr>
        </tbody>
    </table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('content.usuario.contentUsuario', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\LaravelPruebaCIT\LaravelPruebaCIT\resources\views/content/usuario/mostrarPlatoUsuario.blade.php ENDPATH**/ ?>