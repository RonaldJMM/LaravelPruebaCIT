<?php $__env->startSection('contentIndex'); ?>

    <div class="row">
        <div class="col-lg-8"><?php echo $__env->yieldContent('contentPaginaPrincipal'); ?></div>
        <?php if(Session::has('Usuario_Id')): ?>
            
            <div class="col-lg-8"><?php echo $__env->yieldContent('contentUsuario'); ?></div>

        <?php endif; ?>
        <div class="col-lg-4" style="align-content: center"><img src="<?php echo e(url('images/aplication/iconoProject.png')); ?>" style="display:block; " height="95%" width="100%"></div>
    </div>

    
    

<?php $__env->stopSection(); ?>



<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\LaravelPruebaCIT\LaravelPruebaCIT\resources\views/content/content.blade.php ENDPATH**/ ?>