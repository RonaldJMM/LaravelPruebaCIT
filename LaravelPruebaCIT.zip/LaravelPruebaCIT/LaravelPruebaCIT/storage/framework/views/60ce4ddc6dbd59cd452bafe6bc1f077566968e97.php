<?php $__env->startSection('paginaInicio'); ?>
    
    Esta es la pagina de inicio

<?php $__env->stopSection(); ?>
<?php echo $__env->make('content.paginaPrincipal.contentPaginaPrincipal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\LaravelPruebaCIT\LaravelPruebaCIT\resources\views/content\paginaPrincipal\paginaInicio.blade.php ENDPATH**/ ?>