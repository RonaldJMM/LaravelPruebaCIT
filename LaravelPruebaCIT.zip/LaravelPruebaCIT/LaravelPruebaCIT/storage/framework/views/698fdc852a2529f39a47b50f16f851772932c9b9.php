<?php $__env->startSection('editarPlatoUsuario'); ?>

<h1>Edicion de comentario del plato <?php echo e($datosPlato->nombre); ?></h1>
<div class="alert alert-secondary" role="alert">
<table class="table table-sm table-striped table-bordered table-light">
    <thead>
    </thead>
    <tbody>

<form method="POST" action="<?php echo e(route('actualizarComentarioPlato', ['idPlato' => $datosPlato->id, 'idComentario' => $datosComentarioPlato->id])); ?>">

    <?php echo e(method_field('PUT')); ?>

    <?php echo csrf_field(); ?>
    
    <tr>
        <td scope="col" colspan="1"><label for="descripcion">Descripcion:</label></td>
       
        <td scope="col" colspan="2"><textarea class="form-control" name="descripcionComentario" aria-label="With textarea" rows="3" style="resize: none"><?php echo e($datosComentarioPlato->descripcion); ?></textarea></td>
    </tr>

    <tr><td colspan="1"><button type="submit" class="btn btn-info">Actualizar</button></td>
        
</form>

<form method="POST" action="<?php echo e(route('deshabilitarComentarioPlato', ['idPlato' => $datosPlato->id, 'idComentario' => $datosComentarioPlato->id])); ?>">

    <?php echo e(method_field('PUT')); ?>

    <?php echo csrf_field(); ?>
    
    <?php if($datosComentarioPlato->estado_id == 1): ?>
    <td colspan="1"><button type="submit" class="btn btn-danger">Deshabilitar</button></td>
    <?php else: ?>
    <td colspan="1"><button type="submit" class="btn btn-success">Habilitar</button></td>
    <?php endif; ?>
    
</form>
<td colspan="1"><a class="btn btn-danger" href="<?php echo e(route('eliminarComentarioPlato', ['idPlato' => $datosPlato->id, 'idComentario' => $datosComentarioPlato->id])); ?>" role="button">Eliminar</a></td>
</tr>
</tbody>
</table>  
</div>
<a class="btn btn-warning" href="<?php echo e(route('mostrarPlatoUsuario',$datosPlato->id)); ?>" role="button">Regresar</a>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('content.usuario.contentUsuario', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\LaravelPruebaCIT\LaravelPruebaCIT\resources\views/content\usuario\comentario\editarComentarioPlato.blade.php ENDPATH**/ ?>