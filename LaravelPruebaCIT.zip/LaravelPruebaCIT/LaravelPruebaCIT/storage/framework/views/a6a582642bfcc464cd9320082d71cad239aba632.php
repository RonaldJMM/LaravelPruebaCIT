<?php $__env->startSection('homecontent'); ?>

<div class="container">
    <?php if(session('status')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>  
</div>
<br>
<div class="container-fluid"> 
<?php if(Session::has('Usuario_Id')): ?>
    <?php echo $__env->yieldContent('homePrincipal'); ?>
<?php else: ?>
    <?php echo $__env->make('errors.404', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\LaravelPruebaCIT\LaravelPruebaCIT\resources\views/home.blade.php ENDPATH**/ ?>