<?php $__env->startSection('homePrincipal'); ?>

       
    <?php echo $__env->yieldContent('contentIndex'); ?>
    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\LaravelPruebaCIT\LaravelPruebaCIT\resources\views/index.blade.php ENDPATH**/ ?>