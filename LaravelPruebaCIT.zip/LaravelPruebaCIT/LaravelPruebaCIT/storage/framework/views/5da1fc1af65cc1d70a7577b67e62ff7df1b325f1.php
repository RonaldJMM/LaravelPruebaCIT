<?php echo $__env->make('navbar.navbarPrincipal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('contentPaginaPrincipal'); ?>

<?php if($errors->any()): ?>
<div class="alert alert-danger" role="alert">
<h4>Se han presentado los siguientes errores:</h4>
<div>
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
</div>
<?php endif; ?>
    <?php echo $__env->yieldContent('paginaInicio'); ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('content.content', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\LaravelPruebaCIT\LaravelPruebaCIT\resources\views/content/paginaPrincipal/contentPaginaPrincipal.blade.php ENDPATH**/ ?>