
<?php $__env->startSection('navbar'); ?>

    <?php echo $__env->yieldContent('navbarPrincipal'); ?>
    <?php echo $__env->yieldContent('navbarUsuario'); ?>

<?php $__env->stopSection(); ?><?php /**PATH D:\xampp\htdocs\LaravelPruebaCIT\LaravelPruebaCIT\resources\views/navbar/navbar.blade.php ENDPATH**/ ?>