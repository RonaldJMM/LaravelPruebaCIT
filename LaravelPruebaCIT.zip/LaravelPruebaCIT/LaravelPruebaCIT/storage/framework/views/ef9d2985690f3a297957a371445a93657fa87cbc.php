<?php $__env->startSection('listarPlatosUsuario'); ?>

    <h1>Lista de platos de Usuario</h1>
          
    <div class="card bg-secondary text-white">
        <div class="card-body">
            <?php echo e($datosPlatosUsuario->total()); ?> registros | pagina <?php echo e($datosPlatosUsuario->currentPage()); ?> de <?php echo e($datosPlatosUsuario->lastPage()); ?>

        </div>
        </div>
        <br>
    <table class="table table-sm table-striped table-bordered" >
        <thead class="thead-dark">
            <tr>
            <th scope="col">Imagen</th>
            <th scope="col">Nombre</th>
            <th scope="col">Accion</th>                    
            </tr>
        </thead>
        <tbody>
            <tr><td colspan="3"><a class="btn btn-success" href="<?php echo e(route('crearPlatoUsuario')); ?>" role="button"><img style="filter: invert(1)" src="../images/icons/plus-circle-solid.svg" height="30px" width="30px"> Crear Nuevo </a></td></tr>
            <?php $__empty_1 = true; $__currentLoopData = $datosPlatosUsuario; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
            <td><img src="<?php echo e($plato->url_imagen); ?>" class="img-thumbnail border-dark rounded mx-auto d-block" height="50px" width="50px"></td>
            <td><?php echo e($plato->nombre); ?></td>
            <td>
                <center>
                <a class="btn btn-warning" href="<?php echo e(route('mostrarPlatoUsuario', $plato->id)); ?>" role="button"><img style="filter: invert(1)" src="../images/icons/info-circle-solid.svg" height="30px" width="30px"></a>
                
                <a class="btn btn-primary" href="<?php echo e(route('editarPlatoUsuario', $plato->id)); ?>" role="button"><img style="filter: invert(1)" src="../images/icons/edit-solid.svg" height="30px" width="30px"></a>
                
                <form method="POST" action="<?php echo e(route('deshabilitarPlatoUsuarioVista', $plato->id)); ?>">

                    <?php echo e(method_field('PUT')); ?>

                    <?php echo csrf_field(); ?>
                    <?php if($plato->estado_id == 1): ?>
                        <button class="btn btn-success" type="submit"><img style="filter: invert(1)" src="../images/icons/eye-solid.svg" height="30px" width="30px"></button>
                    <?php else: ?>
                        <button class="btn btn-danger" type="submit"><img style="filter: invert(1)" src="../images/icons/eye-slash-solid.svg" height="30px" width="30px"></button>
                    <?php endif; ?>
                </form>
                
                </center>
            </td>
        </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
            <td colspan="3"><?php echo e($NDatosPlatos); ?></td>
            </tr>
            <?php endif; ?>
        </tbody>
        </table>
        <?php echo $datosPlatosUsuario->render(); ?>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('content.usuario.contentUsuario', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\LaravelPruebaCIT\LaravelPruebaCIT\resources\views/content/usuario/listarPlatosUsuario.blade.php ENDPATH**/ ?>