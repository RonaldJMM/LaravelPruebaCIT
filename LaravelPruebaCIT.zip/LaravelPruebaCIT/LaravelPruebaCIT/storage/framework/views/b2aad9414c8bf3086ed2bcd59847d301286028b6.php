<?php $__env->startSection('contentUsuario'); ?>

<?php if($errors->any()): ?>
<div class="alert alert-danger" role="alert">
<h4>Se han presentado los siguientes errores:</h4>
<div>
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
</div>
<?php endif; ?>
    <?php echo $__env->yieldContent('paginaPrincipalUsuario'); ?>
    <?php echo $__env->yieldContent('listarPlatosUsuario'); ?>
    <?php echo $__env->yieldContent('crearPlatoUsuario'); ?>
    <?php echo $__env->yieldContent('mostrarPlatoUsuario'); ?>
    <?php echo $__env->yieldContent('editarPlatoUsuario'); ?>
    <?php echo $__env->yieldContent('listarPlatosGenerales'); ?>
    <?php echo $__env->yieldContent('editarUsuario'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('content.content', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\LaravelPruebaCIT\LaravelPruebaCIT\resources\views/content/usuario/contentUsuario.blade.php ENDPATH**/ ?>