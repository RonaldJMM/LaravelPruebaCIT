<?php $__env->startSection('editarUsuario'); ?>

    <h1>Editar Usuario</h1>
    <div class="alert alert-secondary" role="alert">
    <table class="table table-sm table-striped table-bordered table-light">
        <thead>
        </thead>
        <tbody>

    <form method="POST" action="<?php echo e(route('actualizarUsuario', $datosUsuario->id)); ?>">

        <?php echo e(method_field('PUT')); ?>

        <?php echo csrf_field(); ?>
        
        <tr>
            <td scope="col"><label for="nombre">Nombre:</label></td>
            <td scope="col"><input type="text" name="nombre" id="nombre" placeholder="example" value="<?php echo e($datosUsuario->nombre); ?>"></td>
        </tr>
        
        <tr>
            <td scope="col"><label for="apellido">Apellido:</label></td>
            <td scope="col"><input type="text" name="apellido" id="apellido" value="<?php echo e($datosUsuario->apellido); ?>"></td>
        </tr>
        
        <tr>
            <td scope="col"><label for="descripcion">Correo:</label></td>
            <td scope="col"><input type="text" name="email" id="email" value="<?php echo e($datosUsuario->email); ?>"></td>
        </tr>
        <tr><td colspan="1"><button type="submit" class="btn btn-info">Actualizar</button></td>
    </form>

    <form action="POST" action="<?php echo e(route('actualizarContrasenia')); ?>">

        <?php echo csrf_field(); ?>
         <label for="password">Contraseña:</label>
        <input type="password" name="password">
    
        <button type="submit" class="btn btn-info">Actualizar</button>
    </form>

    </tbody>
    </table>
</div>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('content.usuario.contentUsuario', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\LaravelPruebaCIT\LaravelPruebaCIT\resources\views/content\usuario\editar\editarUsuario.blade.php ENDPATH**/ ?>