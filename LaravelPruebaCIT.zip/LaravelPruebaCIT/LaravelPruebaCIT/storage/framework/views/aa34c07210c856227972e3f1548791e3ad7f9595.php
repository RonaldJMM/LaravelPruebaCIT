<?php $__env->startSection('paginaPrincipalUsuario'); ?>
    Bienvenido 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('content.usuario.contentUsuario', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\LaravelPruebaCIT\LaravelPruebaCIT\resources\views/content\usuario\paginaPrincipalUsuario.blade.php ENDPATH**/ ?>