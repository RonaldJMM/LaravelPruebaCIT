@extends('home')

@section('homePrincipal')

       
    @yield('contentIndex')
    

@endsection