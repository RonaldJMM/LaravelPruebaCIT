
@section('navbar')

    @yield('navbarPrincipal')
    @yield('navbarUsuario')

@endsection