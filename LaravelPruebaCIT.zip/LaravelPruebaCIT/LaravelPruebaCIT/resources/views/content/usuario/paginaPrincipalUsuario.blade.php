
@extends('content.usuario.contentUsuario')

@section('paginaPrincipalUsuario')
    Bienvenido 
@endsection