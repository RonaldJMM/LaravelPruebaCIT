@extends('content.paginaPrincipal.contentPaginaPrincipal')

@section('paginaInicio')
    
    Esta es la pagina de inicio

@endsection